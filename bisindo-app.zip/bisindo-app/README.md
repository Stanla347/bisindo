# 🤟 BISINDO Interpreter

Sistem penerjemah bahasa isyarat BISINDO (Bahasa Isyarat Indonesia) berbasis web menggunakan Claude Vision AI.

## Fitur
- 📷 Deteksi live melalui kamera
- 🖼️ Upload gambar
- 🤚✋ Analisis 2 tangan (kiri & kanan)
- 📝 Pembangun kalimat
- 🔊 Text-to-speech bahasa Indonesia
- 📊 Statistik sesi & riwayat deteksi

## Setup

### 1. Clone & Install
```bash
git clone https://github.com/USERNAME/bisindo-interpreter
cd bisindo-interpreter
npm install
```

### 2. Buat file `.env`
```
REACT_APP_ANTHROPIC_KEY=sk-ant-api03-xxxxx
```

### 3. Jalankan lokal
```bash
npm start
```

## Deploy ke Vercel

1. Push ke GitHub
2. Import di [vercel.com](https://vercel.com)
3. Tambahkan Environment Variable: `REACT_APP_ANTHROPIC_KEY`
4. Deploy!

## Referensi
Berdasarkan penelitian: *BISINDO Sign Language Interpreter System Using YOLOv8 and CNN* — Farhana et al., 2025
