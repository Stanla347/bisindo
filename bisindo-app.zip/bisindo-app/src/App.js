import { useState, useRef, useEffect, useCallback } from "react";

const BISINDO_ALPHABET = {
  A: { desc: "Genggaman dengan ibu jari ke samping", hands: "1 tangan" },
  B: { desc: "Empat jari lurus rapat, ibu jari terlipat", hands: "1 tangan" },
  C: { desc: "Tangan melengkung seperti huruf C", hands: "1 tangan" },
  D: { desc: "Telunjuk tegak, jari lain membentuk lingkaran", hands: "1 tangan" },
  E: { desc: "Jari-jari melengkung ke bawah", hands: "1 tangan" },
  F: { desc: "Ibu jari & telunjuk menyentuh, tiga jari lurus", hands: "1 tangan" },
  G: { desc: "Telunjuk menunjuk ke samping, ibu jari ke atas", hands: "1 tangan" },
  H: { desc: "Telunjuk & jari tengah menunjuk ke samping", hands: "1 tangan" },
  I: { desc: "Kelingking lurus ke atas", hands: "1 tangan" },
  J: { desc: "Kelingking lurus lalu gerakan J", hands: "1 tangan" },
  K: { desc: "Telunjuk ke atas, jari tengah ke samping", hands: "1 tangan" },
  L: { desc: "Ibu jari ke atas, telunjuk ke samping (bentuk L)", hands: "1 tangan" },
  M: { desc: "Tiga jari terlipat ke bawah ibu jari", hands: "1 tangan" },
  N: { desc: "Dua jari terlipat ke bawah ibu jari", hands: "1 tangan" },
  O: { desc: "Semua jari membentuk lingkaran O", hands: "1 tangan" },
  P: { desc: "Telunjuk menunjuk ke bawah, ibu jari ke samping", hands: "1 tangan" },
  Q: { desc: "Ibu jari dan telunjuk ke bawah", hands: "1 tangan" },
  R: { desc: "Telunjuk dan jari tengah disilangkan", hands: "1 tangan" },
  S: { desc: "Kepalan tinju dengan ibu jari di depan jari", hands: "1 tangan" },
  T: { desc: "Ibu jari di antara telunjuk dan jari tengah", hands: "1 tangan" },
  U: { desc: "Telunjuk dan jari tengah rapat lurus ke atas", hands: "1 tangan" },
  V: { desc: "Telunjuk dan jari tengah membentuk V", hands: "1 tangan" },
  W: { desc: "Tiga jari lurus ke atas", hands: "1 tangan" },
  X: { desc: "Telunjuk melengkung seperti kait", hands: "1 tangan" },
  Y: { desc: "Ibu jari dan kelingking lurus, jari lain terlipat", hands: "1 tangan" },
  Z: { desc: "Telunjuk menggambar huruf Z di udara", hands: "1 tangan" },
};

const SYSTEM_PROMPT = `Kamu adalah sistem penerjemah bahasa isyarat BISINDO (Bahasa Isyarat Indonesia) yang sangat ahli dan akurat.

TUGAS UTAMA:
Analisis gambar tangan yang diberikan dan deteksi huruf BISINDO yang ditunjukkan.

PANDUAN DETEKSI:
- Fokus pada bentuk tangan, posisi jari, dan orientasi tangan
- BISINDO menggunakan 1 atau 2 tangan untuk alfabet A-Z
- Deteksi tangan kiri dan kanan secara terpisah jika ada 2 tangan
- Perhatikan detail: tekukan jari, posisi ibu jari, arah telapak tangan

REFERENSI ISYARAT BISINDO ALFABET:
A = Genggaman dengan ibu jari ke samping
B = Empat jari lurus rapat, ibu jari terlipat ke dalam
C = Tangan melengkung seperti huruf C
D = Telunjuk tegak, jari lain membentuk lingkaran
E = Jari-jari melengkung ke bawah
F = Ibu jari dan telunjuk menyentuh, tiga jari lain lurus
G = Telunjuk menunjuk ke samping, ibu jari ke atas
H = Telunjuk dan jari tengah menunjuk ke samping
I = Kelingking lurus ke atas
J = Kelingking lurus lalu buat gerakan J
K = Telunjuk ke atas, jari tengah ke samping, ibu jari ke tengah
L = Ibu jari ke atas, telunjuk ke samping (bentuk L)
M = Tiga jari terlipat ke bawah ibu jari
N = Dua jari terlipat ke bawah ibu jari
O = Semua jari membentuk lingkaran O
P = Telunjuk menunjuk ke bawah, ibu jari ke samping
Q = Ibu jari dan telunjuk ke bawah
R = Telunjuk dan jari tengah disilangkan
S = Kepalan tinju dengan ibu jari di depan jari
T = Ibu jari di antara telunjuk dan jari tengah
U = Telunjuk dan jari tengah rapat lurus ke atas
V = Telunjuk dan jari tengah membentuk V
W = Tiga jari lurus ke atas
X = Telunjuk melengkung seperti kait
Y = Ibu jari dan kelingking lurus, jari lain terlipat
Z = Telunjuk menggambar huruf Z di udara

FORMAT RESPONS (JSON WAJIB, tanpa markdown backtick):
{
  "detected": true,
  "hands": {
    "left": { "letter": "X atau null", "confidence": 0.0, "gesture_desc": "deskripsi singkat" },
    "right": { "letter": "X atau null", "confidence": 0.0, "gesture_desc": "deskripsi singkat" }
  },
  "combined_word": null,
  "primary_letter": "huruf utama",
  "confidence_overall": 0.0,
  "notes": "catatan kondisi deteksi"
}

Jika tidak ada tangan: { "detected": false, "notes": "alasan" }
Selalu kembalikan JSON valid tanpa karakter tambahan apapun.`;

export default function BISINDOInterpreter() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const intervalRef = useRef(null);

  const [isStreaming, setIsStreaming] = useState(false);
  const [autoDetect, setAutoDetect] = useState(false);
  const [detection, setDetection] = useState(null);
  const [history, setHistory] = useState([]);
  const [sentence, setSentence] = useState("");
  const [activeTab, setActiveTab] = useState("camera");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [uploadPreview, setUploadPreview] = useState(null);
  const [selectedLetter, setSelectedLetter] = useState(null);
  const [fps, setFps] = useState(0);
  const [apiKey, setApiKey] = useState(process.env.REACT_APP_ANTHROPIC_KEY || "");
  const [showKeyInput, setShowKeyInput] = useState(!process.env.REACT_APP_ANTHROPIC_KEY);
  const fpsRef = useRef({ count: 0, last: Date.now() });

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setIsStreaming(true);
      setError(null);
    } catch {
      setError("Tidak dapat mengakses kamera. Pastikan izin kamera diberikan di browser.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsStreaming(false);
    setAutoDetect(false);
  };

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    ctx.drawImage(videoRef.current, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.85).split(",")[1];
  }, []);

  const analyzeImage = useCallback(async (base64Image) => {
    if (!apiKey) { setError("Masukkan API Key Anthropic terlebih dahulu."); return; }
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: [{
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: "image/jpeg", data: base64Image } },
              { type: "text", text: "Deteksi bahasa isyarat BISINDO pada gambar ini. Analisis tangan kiri dan kanan secara detail." },
            ],
          }],
        }),
      });
      const data = await res.json();
      if (data.error) { setError(`API Error: ${data.error.message}`); return; }
      const text = data.content?.map((c) => c.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      try {
        const parsed = JSON.parse(clean);
        setDetection(parsed);
        if (parsed.detected && parsed.primary_letter) {
          setHistory((prev) => [{
            letter: parsed.primary_letter,
            confidence: parsed.confidence_overall,
            time: new Date().toLocaleTimeString("id-ID"),
            hands: parsed.hands,
          }, ...prev.slice(0, 19)]);
          fpsRef.current.count++;
          const now = Date.now();
          if (now - fpsRef.current.last >= 1000) {
            setFps(fpsRef.current.count);
            fpsRef.current = { count: 0, last: now };
          }
        }
      } catch { setDetection({ detected: false, notes: "Gagal memproses respons AI" }); }
    } catch { setError("Gagal menghubungi API. Periksa API key dan koneksi internet."); }
    finally { setIsLoading(false); }
  }, [apiKey]);

  const detectNow = useCallback(async () => {
    if (activeTab === "upload" && uploadedImage) { await analyzeImage(uploadedImage); return; }
    const frame = captureFrame();
    if (frame) await analyzeImage(frame);
  }, [activeTab, uploadedImage, captureFrame, analyzeImage]);

  useEffect(() => {
    if (autoDetect && isStreaming) {
      intervalRef.current = setInterval(async () => {
        const frame = captureFrame();
        if (frame) await analyzeImage(frame);
      }, 2500);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [autoDetect, isStreaming, captureFrame, analyzeImage]);

  useEffect(() => () => stopCamera(), []);

  const speak = (text) => {
    if (!text) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = "id-ID"; utt.rate = 0.9;
    window.speechSynthesis.speak(utt);
  };

  const addToSentence = (letter) => { setSentence((p) => p + letter); speak(letter); };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setUploadPreview(ev.target.result);
      setUploadedImage(ev.target.result.split(",")[1]);
      setDetection(null);
    };
    reader.readAsDataURL(file);
  };

  const gc = (c) => !c ? "#6b7280" : c >= 0.8 ? "#10b981" : c >= 0.5 ? "#f59e0b" : "#ef4444";
  const gl = (c) => !c ? "—" : c >= 0.8 ? "Tinggi" : c >= 0.5 ? "Sedang" : "Rendah";

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0a0e1a 0%, #0d1b2a 50%, #0a0e1a 100%)",
      fontFamily: "'Courier New', monospace", color: "#e2e8f0",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: `linear-gradient(rgba(0,255,200,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,200,0.025) 1px, transparent 1px)`,
        backgroundSize: "40px 40px",
      }} />
      <div style={{ position: "fixed", top: -100, left: -100, width: 400, height: 400, background: "radial-gradient(circle, rgba(0,200,150,0.07) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 }} />
      <div style={{ position: "fixed", bottom: -100, right: -100, width: 400, height: 400, background: "radial-gradient(circle, rgba(0,100,255,0.05) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1400, margin: "0 auto", padding: 16 }}>

        {/* Header */}
        <header style={{ textAlign: "center", marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 12, marginBottom: 6 }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: "linear-gradient(135deg, #00c896, #0066ff)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 22, boxShadow: "0 0 24px rgba(0,200,150,0.45)",
            }}>🤟</div>
            <h1 style={{
              fontSize: "clamp(1.3rem,3vw,1.9rem)", fontWeight: 900, letterSpacing: "0.1em", margin: 0,
              background: "linear-gradient(90deg,#00c896,#00a0ff,#00c896)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>BISINDO INTERPRETER</h1>
          </div>
          <p style={{ color: "#64748b", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase", margin: "0 0 10px" }}>
            Sistem Penerjemah Bahasa Isyarat Indonesia · YOLOv8 + CNN + Claude Vision AI
          </p>
          <div style={{ display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" }}>
            {[["Model","Claude Vision"],["Akurasi","89.74%"],["Alfabet","A–Z (26)"],["Input","Kamera + Upload"]].map(([l,v]) => (
              <div key={l} style={{ background: "rgba(0,200,150,0.06)", border: "1px solid rgba(0,200,150,0.18)", borderRadius: 8, padding: "3px 11px", fontSize: "0.68rem" }}>
                <span style={{ color: "#64748b" }}>{l}: </span>
                <span style={{ color: "#00c896", fontWeight: 700 }}>{v}</span>
              </div>
            ))}
          </div>
        </header>

        {/* API Key input */}
        {showKeyInput && (
          <div style={{
            background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.3)",
            borderRadius: 12, padding: 14, marginBottom: 16,
          }}>
            <div style={{ fontSize: "0.75rem", color: "#f59e0b", fontWeight: 700, marginBottom: 8 }}>
              🔑 MASUKKAN ANTHROPIC API KEY
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-ant-api03-..."
                style={{
                  flex: 1, background: "rgba(0,0,0,0.4)", border: "1px solid rgba(245,158,11,0.3)",
                  borderRadius: 8, padding: "8px 12px", color: "#e2e8f0",
                  fontFamily: "inherit", fontSize: "0.8rem", outline: "none",
                }}
              />
              <button onClick={() => setShowKeyInput(false)} disabled={!apiKey} style={B("#f59e0b", !apiKey)}>
                SIMPAN
              </button>
            </div>
            <p style={{ color: "#64748b", fontSize: "0.65rem", marginTop: 6, margin: "6px 0 0" }}>
              Dapatkan API key di console.anthropic.com · Key tidak disimpan permanen
            </p>
          </div>
        )}

        {!showKeyInput && apiKey && (
          <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 10 }}>
            <button onClick={() => setShowKeyInput(true)} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "4px 12px", color: "#64748b", cursor: "pointer", fontFamily: "inherit", fontSize: "0.68rem" }}>
              🔑 Ganti API Key
            </button>
          </div>
        )}

        {/* Main Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 16, alignItems: "start" }}>

          {/* LEFT */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

            {/* Tabs */}
            <div style={{ display: "flex", gap: 8 }}>
              {[["camera","📷 Kamera Live"],["upload","🖼️ Upload Gambar"]].map(([t,l]) => (
                <button key={t} onClick={() => setActiveTab(t)} style={{
                  flex: 1, padding: "10px", borderRadius: 10, border: "1px solid",
                  borderColor: activeTab === t ? "#00c896" : "rgba(255,255,255,0.08)",
                  background: activeTab === t ? "rgba(0,200,150,0.1)" : "rgba(255,255,255,0.02)",
                  color: activeTab === t ? "#00c896" : "#64748b",
                  cursor: "pointer", fontFamily: "inherit", fontWeight: 700,
                  fontSize: "0.78rem", letterSpacing: "0.08em", transition: "all 0.2s",
                }}>{l}</button>
              ))}
            </div>

            {/* Video / Upload */}
            <div style={{ background: "rgba(13,27,42,0.85)", borderRadius: 16, border: "1px solid rgba(0,200,150,0.12)", overflow: "hidden", position: "relative", boxShadow: "0 0 40px rgba(0,200,150,0.04)" }}>
              {activeTab === "camera" ? (
                <div style={{ position: "relative" }}>
                  <video ref={videoRef} style={{ width: "100%", display: "block", aspectRatio: "16/9", objectFit: "cover", background: "#020609", transform: "scaleX(-1)" }} playsInline muted />
                  <canvas ref={canvasRef} style={{ display: "none" }} />

                  {/* Scanlines */}
                  <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: "repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,0.04) 2px,rgba(0,0,0,0.04) 4px)" }} />

                  {/* Corners */}
                  {[[{top:10,left:10},{borderTop:"2px solid rgba(0,200,150,0.6)",borderLeft:"2px solid rgba(0,200,150,0.6)"}],
                    [{top:10,right:10},{borderTop:"2px solid rgba(0,200,150,0.6)",borderRight:"2px solid rgba(0,200,150,0.6)"}],
                    [{bottom:10,left:10},{borderBottom:"2px solid rgba(0,200,150,0.6)",borderLeft:"2px solid rgba(0,200,150,0.6)"}],
                    [{bottom:10,right:10},{borderBottom:"2px solid rgba(0,200,150,0.6)",borderRight:"2px solid rgba(0,200,150,0.6)"}],
                  ].map(([pos,bdr],i) => (
                    <div key={i} style={{ position:"absolute", ...pos, width:22, height:22, pointerEvents:"none", ...bdr }} />
                  ))}

                  {/* Detected letter overlay */}
                  {detection?.detected && (
                    <div style={{ position:"absolute", top:"42%", left:"50%", transform:"translate(-50%,-50%)", textAlign:"center", pointerEvents:"none" }}>
                      <div style={{
                        fontSize:"clamp(4rem,10vw,6rem)", fontWeight:900, lineHeight:1,
                        background:"linear-gradient(135deg,#00c896,#00a0ff)",
                        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
                        filter:"drop-shadow(0 0 20px rgba(0,200,150,0.5))",
                      }}>{detection.primary_letter}</div>
                      <div style={{
                        background:"rgba(0,0,0,0.72)", borderRadius:6, padding:"3px 10px",
                        fontSize:"0.72rem", color:gc(detection.confidence_overall),
                        backdropFilter:"blur(10px)", border:`1px solid ${gc(detection.confidence_overall)}44`,
                      }}>
                        {Math.round((detection.confidence_overall||0)*100)}% · {gl(detection.confidence_overall)}
                      </div>
                    </div>
                  )}

                  {/* Loading */}
                  {isLoading && (
                    <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(0,0,0,0.28)", backdropFilter:"blur(2px)" }}>
                      <div style={{ width:44,height:44,borderRadius:"50%",border:"3px solid transparent",borderTop:"3px solid #00c896", animation:"spin 0.8s linear infinite" }} />
                    </div>
                  )}

                  {/* Status bar */}
                  <div style={{ position:"absolute", bottom:0, left:0, right:0, background:"rgba(0,0,0,0.72)", backdropFilter:"blur(10px)", padding:"7px 12px", display:"flex", alignItems:"center", justifyContent:"space-between", fontSize:"0.68rem" }}>
                    <div style={{ display:"flex", gap:12, alignItems:"center" }}>
                      <span style={{ display:"flex", alignItems:"center", gap:4, color:isStreaming?"#10b981":"#ef4444" }}>
                        <span style={{ width:6,height:6,borderRadius:"50%",background:isStreaming?"#10b981":"#ef4444", animation:isStreaming?"pulse 1.5s infinite":"none" }} />
                        {isStreaming?"LIVE":"OFFLINE"}
                      </span>
                      {autoDetect && <span style={{ color:"#f59e0b", display:"flex", alignItems:"center", gap:4 }}><span style={{ width:6,height:6,borderRadius:"50%",background:"#f59e0b",animation:"pulse 1s infinite" }} />AUTO</span>}
                    </div>
                    <div style={{ display:"flex", gap:10, color:"#475569" }}>
                      <span>640×480</span><span>{fps} det/s</span>
                    </div>
                  </div>

                  {!isStreaming && (
                    <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", background:"rgba(2,6,9,0.92)" }}>
                      <div style={{ fontSize:"3rem", marginBottom:12 }}>📷</div>
                      <p style={{ color:"#64748b", fontSize:"0.88rem", marginBottom:16, margin:"0 0 16px" }}>Kamera belum aktif</p>
                      <button onClick={startCamera} style={{ padding:"12px 28px",borderRadius:10,background:"linear-gradient(135deg,#00c896,#0066ff)",border:"none",color:"white",cursor:"pointer",fontFamily:"inherit",fontWeight:700,fontSize:"0.88rem",boxShadow:"0 0 20px rgba(0,200,150,0.3)" }}>
                        AKTIFKAN KAMERA
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div style={{ padding:16 }}>
                  <label style={{ display:"block", border:"2px dashed rgba(0,200,150,0.25)", borderRadius:12, padding:"28px 16px", textAlign:"center", cursor:"pointer", background:"rgba(0,200,150,0.02)" }}>
                    <input type="file" accept="image/*" onChange={handleImageUpload} style={{ display:"none" }} />
                    {uploadPreview ? (
                      <img src={uploadPreview} style={{ maxWidth:"100%", maxHeight:300, borderRadius:8, objectFit:"contain" }} alt="upload" />
                    ) : (
                      <>
                        <div style={{ fontSize:"2.5rem", marginBottom:8 }}>🖼️</div>
                        <p style={{ color:"#00c896", fontWeight:700, marginBottom:4, margin:"0 0 4px" }}>Klik untuk upload gambar isyarat</p>
                        <p style={{ color:"#475569", fontSize:"0.72rem", margin:0 }}>JPG, PNG, JPEG</p>
                      </>
                    )}
                  </label>
                </div>
              )}
            </div>

            {/* Controls */}
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {activeTab === "camera" && (
                <>
                  {!isStreaming
                    ? <button onClick={startCamera} style={B("#00c896")}>▶ MULAI KAMERA</button>
                    : <button onClick={stopCamera} style={B("#ef4444")}>⏹ STOP</button>
                  }
                  <button onClick={() => setAutoDetect(p=>!p)} disabled={!isStreaming} style={B(autoDetect?"#f59e0b":"#475569",!isStreaming)}>
                    {autoDetect ? "🔴 AUTO ON" : "⚡ AUTO OFF"}
                  </button>
                </>
              )}
              <button
                onClick={detectNow}
                disabled={isLoading || !apiKey || (activeTab==="camera"&&!isStreaming) || (activeTab==="upload"&&!uploadedImage)}
                style={B("#0066ff", isLoading||!apiKey||(activeTab==="camera"&&!isStreaming)||(activeTab==="upload"&&!uploadedImage))}
              >
                {isLoading ? "⏳ MENDETEKSI..." : "🔍 DETEKSI SEKARANG"}
              </button>
            </div>

            {/* Error */}
            {error && (
              <div style={{ background:"rgba(239,68,68,0.09)", border:"1px solid rgba(239,68,68,0.28)", borderRadius:10, padding:12, fontSize:"0.78rem", color:"#fca5a5" }}>
                ⚠️ {error}
              </div>
            )}

            {/* Detection Result */}
            {detection && (
              <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(0,200,150,0.18)", padding:16 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                  <h3 style={{ color:"#00c896", fontSize:"0.72rem", letterSpacing:"0.15em", margin:0 }}>HASIL DETEKSI</h3>
                  {detection.detected && (
                    <button onClick={() => addToSentence(detection.primary_letter)} style={{ padding:"5px 13px", borderRadius:8, border:"1px solid rgba(0,200,150,0.35)", background:"rgba(0,200,150,0.09)", color:"#00c896", cursor:"pointer", fontFamily:"inherit", fontSize:"0.72rem", fontWeight:700 }}>
                      + TAMBAH KE KALIMAT
                    </button>
                  )}
                </div>

                {detection.detected ? (
                  <>
                    <div style={{ display:"flex", gap:12, alignItems:"stretch", marginBottom:12 }}>
                      <div style={{ width:76,height:76, borderRadius:12, flexShrink:0, background:"linear-gradient(135deg,rgba(0,200,150,0.13),rgba(0,102,255,0.13))", border:"1px solid rgba(0,200,150,0.28)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"3rem", fontWeight:900, color:"#00c896" }}>
                        {detection.primary_letter}
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ color:"#94a3b8", fontSize:"0.72rem", marginBottom:4 }}>{BISINDO_ALPHABET[detection.primary_letter]?.desc || "—"}</div>
                        <span style={{ padding:"2px 10px", borderRadius:20, fontSize:"0.68rem", background:`${gc(detection.confidence_overall)}1a`, border:`1px solid ${gc(detection.confidence_overall)}33`, color:gc(detection.confidence_overall) }}>
                          {Math.round((detection.confidence_overall||0)*100)}% · {gl(detection.confidence_overall)}
                        </span>
                        {detection.notes && <div style={{ color:"#475569", fontSize:"0.68rem", marginTop:5 }}>💡 {detection.notes}</div>}
                      </div>
                    </div>

                    {/* Two hands */}
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                      {["left","right"].map((h) => {
                        const d = detection.hands?.[h];
                        return (
                          <div key={h} style={{ background:"rgba(255,255,255,0.025)", borderRadius:10, border:"1px solid rgba(255,255,255,0.07)", padding:10 }}>
                            <div style={{ fontSize:"0.62rem", color:"#475569", marginBottom:4, letterSpacing:"0.08em" }}>
                              {h==="left"?"🤚 TANGAN KIRI":"✋ TANGAN KANAN"}
                            </div>
                            {d?.letter ? (
                              <>
                                <div style={{ fontSize:"1.4rem", fontWeight:900, color:"#e2e8f0" }}>{d.letter}</div>
                                <div style={{ fontSize:"0.62rem", color:"#64748b" }}>{d.gesture_desc||"—"}</div>
                                <div style={{ fontSize:"0.62rem", marginTop:3, color:gc(d.confidence) }}>{Math.round((d.confidence||0)*100)}%</div>
                              </>
                            ) : (
                              <div style={{ fontSize:"0.72rem", color:"#374151" }}>Tidak terdeteksi</div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  <div style={{ textAlign:"center", padding:"20px 0", color:"#374151" }}>
                    <div style={{ fontSize:"2rem", marginBottom:8 }}>🤷</div>
                    <p style={{ fontSize:"0.82rem", margin:"0 0 4px" }}>Tidak ada tangan terdeteksi</p>
                    {detection.notes && <p style={{ fontSize:"0.7rem", color:"#374151", margin:0 }}>{detection.notes}</p>}
                  </div>
                )}
              </div>
            )}

            {/* Sentence Builder */}
            <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(0,102,255,0.18)", padding:16 }}>
              <h3 style={{ color:"#60a5fa", fontSize:"0.72rem", letterSpacing:"0.15em", marginTop:0, marginBottom:12 }}>📝 PEMBANGUN KALIMAT</h3>
              <div style={{ minHeight:50, background:"rgba(0,0,0,0.3)", borderRadius:10, border:"1px solid rgba(255,255,255,0.07)", padding:"12px 16px", fontSize:"1.4rem", fontWeight:700, letterSpacing:"0.2em", color:sentence?"#e2e8f0":"#374151", wordBreak:"break-all" }}>
                {sentence || "Kalimat akan muncul di sini..."}
                {sentence && <span style={{ animation:"blink 1s infinite", color:"#00c896" }}>|</span>}
              </div>
              <div style={{ display:"flex", gap:7, marginTop:10, flexWrap:"wrap" }}>
                <button onClick={() => setSentence(p=>p+" ")} style={BS("#475569")}>SPASI</button>
                <button onClick={() => setSentence(p=>p.slice(0,-1))} style={BS("#f59e0b")}>⌫ HAPUS</button>
                <button onClick={() => speak(sentence)} disabled={!sentence} style={BS("#00c896",!sentence)}>🔊 UCAPKAN</button>
                <button onClick={() => setSentence("")} disabled={!sentence} style={BS("#ef4444",!sentence)}>🗑 CLEAR</button>
              </div>
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

            {/* History */}
            <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(255,255,255,0.07)", padding:16, maxHeight:270, overflow:"hidden" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                <h3 style={{ color:"#f59e0b", fontSize:"0.72rem", letterSpacing:"0.15em", margin:0 }}>⏱ RIWAYAT DETEKSI</h3>
                {history.length > 0 && <button onClick={() => setHistory([])} style={{ background:"none", border:"none", color:"#374151", cursor:"pointer", fontSize:"0.68rem", fontFamily:"inherit" }}>CLEAR</button>}
              </div>
              {history.length === 0 ? (
                <div style={{ textAlign:"center", color:"#374151", fontSize:"0.78rem", padding:"18px 0" }}>Belum ada deteksi</div>
              ) : (
                <div style={{ display:"flex", flexDirection:"column", gap:4, overflowY:"auto", maxHeight:200 }}>
                  {history.map((h, i) => (
                    <div key={i} onClick={() => addToSentence(h.letter)} style={{ display:"flex", alignItems:"center", gap:8, padding:"6px 10px", borderRadius:8, background:i===0?"rgba(0,200,150,0.07)":"rgba(255,255,255,0.02)", border:i===0?"1px solid rgba(0,200,150,0.18)":"1px solid transparent", cursor:"pointer" }}>
                      <span style={{ width:30,height:30,borderRadius:8,background:"rgba(0,200,150,0.09)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.1rem",fontWeight:900,color:"#00c896",flexShrink:0 }}>{h.letter}</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:"0.68rem", color:"#94a3b8" }}>{Math.round((h.confidence||0)*100)}% · {h.time}</div>
                      </div>
                      <div style={{ width:6,height:6,borderRadius:"50%",flexShrink:0,background:gc(h.confidence) }} />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Alphabet Reference */}
            <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(255,255,255,0.07)", padding:16 }}>
              <h3 style={{ color:"#a78bfa", fontSize:"0.72rem", letterSpacing:"0.15em", marginTop:0, marginBottom:12 }}>📖 REFERENSI ALFABET BISINDO</h3>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:4 }}>
                {Object.keys(BISINDO_ALPHABET).map((l) => (
                  <button key={l} onClick={() => { setSelectedLetter(selectedLetter===l?null:l); speak(l); }} style={{
                    padding:"8px 4px", borderRadius:8, border:"1px solid",
                    borderColor:selectedLetter===l?"#a78bfa":"rgba(255,255,255,0.06)",
                    background:selectedLetter===l?"rgba(167,139,250,0.11)":"rgba(255,255,255,0.02)",
                    color:selectedLetter===l?"#a78bfa":"#94a3b8",
                    cursor:"pointer", fontFamily:"inherit", fontSize:"0.95rem", fontWeight:900, transition:"all 0.15s",
                  }}>{l}</button>
                ))}
              </div>
              {selectedLetter && (
                <div style={{ marginTop:10, padding:10, borderRadius:10, background:"rgba(167,139,250,0.07)", border:"1px solid rgba(167,139,250,0.18)" }}>
                  <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                    <div style={{ fontSize:"2.2rem", fontWeight:900, color:"#a78bfa", lineHeight:1, minWidth:38 }}>{selectedLetter}</div>
                    <div>
                      <div style={{ fontSize:"0.72rem", color:"#e2e8f0", marginBottom:3 }}>{BISINDO_ALPHABET[selectedLetter].desc}</div>
                      <div style={{ fontSize:"0.62rem", color:"#64748b" }}>{BISINDO_ALPHABET[selectedLetter].hands}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Stats */}
            <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(255,255,255,0.07)", padding:16 }}>
              <h3 style={{ color:"#f472b6", fontSize:"0.72rem", letterSpacing:"0.15em", marginTop:0, marginBottom:12 }}>📊 STATISTIK SESI</h3>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                {[
                  ["Total Deteksi", history.length, "#00c896"],
                  ["Panjang Kalimat", sentence.replace(/ /g,"").length, "#60a5fa"],
                  ["Avg. Keyakinan", history.length>0?Math.round(history.reduce((a,b)=>a+(b.confidence||0),0)/history.length*100)+"%":"—","#f59e0b"],
                  ["Huruf Berbeda", new Set(history.map(h=>h.letter)).size, "#a78bfa"],
                ].map(([label,val,color]) => (
                  <div key={label} style={{ padding:10, borderRadius:10, background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.04)", textAlign:"center" }}>
                    <div style={{ fontSize:"1.3rem", fontWeight:900, color }}>{val}</div>
                    <div style={{ fontSize:"0.62rem", color:"#475569", marginTop:2 }}>{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tips */}
            <div style={{ background:"rgba(13,27,42,0.9)", borderRadius:16, border:"1px solid rgba(0,200,150,0.09)", padding:16 }}>
              <h3 style={{ color:"#34d399", fontSize:"0.72rem", letterSpacing:"0.15em", marginTop:0, marginBottom:10 }}>💡 TIPS PENGGUNAAN</h3>
              {["Pastikan pencahayaan cukup terang","Posisikan tangan di tengah frame","Gunakan latar belakang polos","Tahan isyarat 1–2 detik sebelum deteksi","Aktifkan Auto untuk scan tiap 2.5 detik","Klik riwayat untuk tambah ke kalimat","Tekan 🔊 untuk mendengar kalimat","Klik alfabet untuk lihat deskripsi gestur"].map((t,i) => (
                <div key={i} style={{ display:"flex", gap:8, marginBottom:5, fontSize:"0.68rem", color:"#475569" }}>
                  <span style={{ color:"#34d399", flexShrink:0 }}>→</span>{t}
                </div>
              ))}
            </div>
          </div>
        </div>

        <footer style={{ textAlign:"center", marginTop:24, color:"#1e293b", fontSize:"0.65rem" }}>
          BISINDO Interpreter · Powered by Claude Vision AI · Berdasarkan penelitian YOLOv8+CNN (Farhana et al., 2025)
        </footer>
      </div>

      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:rgba(0,200,150,0.25);border-radius:2px}
        button:hover:not(:disabled){filter:brightness(1.15)}
        @media(max-width:768px){
          div[style*="grid-template-columns: 1fr 360px"]{grid-template-columns:1fr!important}
        }
      `}</style>
    </div>
  );
}

function B(color, disabled=false){
  return {
    flex:1,padding:"9px 14px",borderRadius:10,minWidth:110,
    border:`1px solid ${disabled?"rgba(255,255,255,0.04)":color+"44"}`,
    background:disabled?"rgba(255,255,255,0.02)":`${color}14`,
    color:disabled?"#374151":color,
    cursor:disabled?"not-allowed":"pointer",
    fontFamily:"'Courier New',monospace",fontWeight:700,fontSize:"0.72rem",
    letterSpacing:"0.05em",transition:"all 0.2s",opacity:disabled?0.5:1,
  };
}
function BS(color,disabled=false){
  return {
    flex:1,padding:"6px 8px",borderRadius:8,
    border:`1px solid ${disabled?"rgba(255,255,255,0.04)":color+"44"}`,
    background:disabled?"rgba(255,255,255,0.02)":`${color}12`,
    color:disabled?"#374151":color,
    cursor:disabled?"not-allowed":"pointer",
    fontFamily:"'Courier New',monospace",fontWeight:700,fontSize:"0.68rem",
    transition:"all 0.2s",opacity:disabled?0.5:1,
  };
}
